package com.skinswap.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private data class Existing(val doc: DocumentFile, val name: String, val uuid: String?)
    private data class PackInfo(val prefix: String, val name: String, val uuid: String?, val type: String?)

    private val reqTree = 101
    private val reqPack = 102
    private val mc = "com.mojang.minecraftpe"
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var statusView: TextView
    private lateinit var packView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var spinner: Spinner

    private var treeUri: Uri? = null
    private var packUri: Uri? = null
    private var skinDir: DocumentFile? = null
    private var existing: List<Existing> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        val saved = getSharedPreferences("skinswap", MODE_PRIVATE).getString("tree", null)
        if (saved != null) {
            val u = Uri.parse(saved)
            val ok = contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission }
            if (ok) {
                treeUri = u
                refreshFolder()
            }
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(24))
        }

        fun text(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

        fun btn(s: String, onClick: () -> Unit) = Button(this).apply {
            text = s
            transformationMethod = null
            setOnClickListener { onClick() }
        }

        col.addView(text("SkinSwap", 26f, true))
        col.addView(text("Minecraft Bedrock ke skin pack ko 4D skin pack se replace karo", 14f))

        statusView = text("Folder: abhi choose nahi kiya", 13f)
        col.addView(btn("Step 1: skin_packs folder choose karo") { pickTree() })
        col.addView(statusView)

        packView = text("Pack: abhi choose nahi kiya", 13f)
        col.addView(btn("Step 2: 4D skin pack (.mcpack / .zip) choose karo") { pickPack() })
        col.addView(packView)

        col.addView(text("Step 3: kise replace karna hai?", 14f, true))
        spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Naya add karo (kuch replace nahi)")
        )
        col.addView(spinner)

        col.addView(btn("Replace / Install karo") { install() })
        col.addView(btn("Fallback: Minecraft se import karo") { importViaMinecraft() })
        col.addView(btn("Minecraft kholo") { openMinecraft() })

        logView = text("", 12f)
        logScroll = ScrollView(this).apply {
            addView(logView)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
            )
        }
        col.addView(logScroll)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun log(msg: String) = runOnUiThread {
        logView.append(msg + "\n")
        logScroll.post { logScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- pickers

    private fun pickTree() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
            if (Build.VERSION.SDK_INT >= 26) {
                putExtra(
                    DocumentsContract.EXTRA_INITIAL_URI,
                    DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents",
                        "primary:Android/data/$mc/files/games/com.mojang/skin_packs"
                    )
                )
            }
        }
        try {
            startActivityForResult(i, reqTree)
        } catch (e: Exception) {
            toast("Folder picker nahi khula: ${e.message}")
        }
    }

    private fun pickPack() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, reqPack)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!

        when (requestCode) {
            reqTree -> {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                treeUri = uri
                getSharedPreferences("skinswap", MODE_PRIVATE).edit()
                    .putString("tree", uri.toString()).apply()
                refreshFolder()
            }

            reqPack -> {
                packUri = uri
                packView.text = "Pack: ${queryName(uri) ?: uri.lastPathSegment}"
            }
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    // ---------------------------------------------------------------- folder

    private fun resolveSkinPacks(uri: Uri): DocumentFile? {
        val root = DocumentFile.fromTreeUri(this, uri) ?: return null
        if (root.name == "skin_packs") return root

        root.findFile("skin_packs")?.takeIf { it.isDirectory }?.let { return it }
        root.findFile("com.mojang")?.findFile("skin_packs")?.takeIf { it.isDirectory }?.let { return it }
        root.findFile("games")?.findFile("com.mojang")?.findFile("skin_packs")
            ?.takeIf { it.isDirectory }?.let { return it }

        if (root.name == "com.mojang") return root.createDirectory("skin_packs")
        return null
    }

    private fun listExisting(dir: DocumentFile): List<Existing> =
        dir.listFiles().filter { it.isDirectory }.map { d ->
            var name = d.name ?: "?"
            var uuid: String? = null
            try {
                val m = d.findFile("manifest.json")
                if (m != null) {
                    val txt = contentResolver.openInputStream(m.uri)?.use {
                        it.readBytes().toString(Charsets.UTF_8)
                    }
                    if (txt != null) {
                        val h = JSONObject(txt.trimStart('﻿')).optJSONObject("header")
                        h?.optString("name")?.takeIf { it.isNotBlank() }?.let { name = it }
                        uuid = h?.optString("uuid")?.takeIf { it.isNotBlank() }
                    }
                }
            } catch (_: Exception) {
            }
            Existing(d, name, uuid)
        }

    private fun refreshFolder() {
        val uri = treeUri ?: return
        io.execute {
            try {
                val dir = resolveSkinPacks(uri)
                if (dir == null) {
                    skinDir = null
                    runOnUiThread {
                        statusView.text = "Folder: skin_packs nahi mila. com.mojang ya skin_packs folder choose karo."
                    }
                    log("skin_packs folder resolve nahi hua. Agar Android 13+ hai to neeche README ka note dekho.")
                    return@execute
                }
                skinDir = dir
                existing = listExisting(dir)
                val items = listOf("Naya add karo (kuch replace nahi)") +
                    existing.map { "Replace: ${it.name}  [${it.doc.name}]" }
                runOnUiThread {
                    statusView.text = "Folder: OK (${existing.size} packs mile)"
                    spinner.adapter = ArrayAdapter(
                        this, android.R.layout.simple_spinner_dropdown_item, items
                    )
                }
            } catch (e: Exception) {
                log("Folder error: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------- pack scan + install

    private fun scanPack(uri: Uri): PackInfo {
        var bestPath: String? = null
        var bestText: String? = null

        contentResolver.openInputStream(uri)!!.use { raw ->
            ZipInputStream(raw).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    val n = e.name.replace('\\', '/')
                    if (!e.isDirectory && !n.contains("__MACOSX") &&
                        (n == "manifest.json" || n.endsWith("/manifest.json"))
                    ) {
                        val cur = bestPath
                        if (cur == null || n.length < cur.length) {
                            bestPath = n
                            bestText = zis.readBytes().toString(Charsets.UTF_8)
                        }
                    }
                    zis.closeEntry()
                    e = zis.nextEntry
                }
            }
        }

        val path = bestPath ?: throw IllegalStateException("manifest.json nahi mila, ye valid skin pack nahi hai")
        val json = JSONObject((bestText ?: "").trimStart('﻿'))
        val header = json.optJSONObject("header")
        val type = json.optJSONArray("modules")?.optJSONObject(0)?.optString("type")
        return PackInfo(
            prefix = path.removeSuffix("manifest.json"),
            name = header?.optString("name")?.takeIf { it.isNotBlank() } ?: "skinpack",
            uuid = header?.optString("uuid")?.takeIf { it.isNotBlank() },
            type = type
        )
    }

    private fun install() {
        val pack = packUri
        val dir = skinDir
        if (pack == null) { toast("Pehle Step 2 me pack choose karo"); return }
        if (dir == null) { toast("Pehle Step 1 me skin_packs folder choose karo"); return }
        val replaceIdx = spinner.selectedItemPosition - 1

        io.execute {
            try {
                log("Pack padh raha hun...")
                val info = scanPack(pack)
                log("Mila: ${info.name} (type: ${info.type ?: "?"})")
                if (info.type != null && info.type != "skin_pack") {
                    log("Warning: ye skin_pack type nahi hai, phir bhi aage badh raha hun.")
                }

                val folderName = info.name.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifEmpty { "skinpack" }

                // 1) purana pack hatao
                val toDelete = mutableListOf<Existing>()
                if (replaceIdx in existing.indices) toDelete.add(existing[replaceIdx])
                existing.forEach { ex ->
                    val same = ex.uuid != null && ex.uuid == info.uuid
                    if ((same || ex.doc.name == folderName) && toDelete.none { it.doc.uri == ex.doc.uri }) {
                        toDelete.add(ex)
                    }
                }
                toDelete.forEach {
                    log("Hata raha hun: ${it.doc.name}")
                    if (!it.doc.delete()) log("Delete nahi hua: ${it.doc.name}")
                }

                // 2) naya folder
                val target = dir.createDirectory(folderName)
                    ?: throw IllegalStateException("Naya folder nahi ban paya. Permission check karo.")

                val dirCache = HashMap<String, DocumentFile>()
                dirCache[""] = target
                fun dirFor(path: String): DocumentFile? {
                    dirCache[path]?.let { return it }
                    val parent = dirFor(path.substringBeforeLast('/', "")) ?: return null
                    val name = path.substringAfterLast('/')
                    val d = parent.findFile(name) ?: parent.createDirectory(name)
                    if (d != null) dirCache[path] = d
                    return d
                }

                // 3) files nikalo
                var count = 0
                contentResolver.openInputStream(pack)!!.use { raw ->
                    ZipInputStream(raw).use { zis ->
                        var e = zis.nextEntry
                        while (e != null) {
                            val n = e.name.replace('\\', '/')
                            if (n.startsWith(info.prefix) && !n.contains("__MACOSX")) {
                                val rel = n.removePrefix(info.prefix)
                                if (rel.isNotEmpty() && rel.split('/').none { it == ".." }) {
                                    if (e.isDirectory) {
                                        dirFor(rel.trimEnd('/'))
                                    } else {
                                        val parent = dirFor(rel.substringBeforeLast('/', ""))
                                        val fname = rel.substringAfterLast('/')
                                        val f = parent?.createFile("application/octet-stream", fname)
                                        if (f != null) {
                                            contentResolver.openOutputStream(f.uri)?.use { out ->
                                                zis.copyTo(out)
                                            }
                                            count++
                                        } else {
                                            log("File nahi ban payi: $rel")
                                        }
                                    }
                                }
                            }
                            zis.closeEntry()
                            e = zis.nextEntry
                        }
                    }
                }

                log("Ho gaya! $count files '$folderName' me likhi gayi.")
                log("Minecraft ko force stop karke dobara kholo.")
                toast("Replace complete")
                refreshFolder()
            } catch (e: Exception) {
                log("Error: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------- fallback + launch

    private fun importViaMinecraft() {
        val pack = packUri
        if (pack == null) { toast("Pehle Step 2 me pack choose karo"); return }

        io.execute {
            try {
                val folder = File(cacheDir, "shared").apply {
                    mkdirs()
                    listFiles()?.forEach { it.delete() }
                }
                val base = (queryName(pack) ?: "skinpack").substringBeforeLast('.')
                    .replace(Regex("[^A-Za-z0-9._-]"), "_")
                val out = File(folder, "$base.mcpack")
                contentResolver.openInputStream(pack)!!.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", out)

                runOnUiThread {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/octet-stream")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        setPackage(mc)
                    }
                    try {
                        startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        toast("Minecraft install nahi hai ya import intent nahi mila")
                    }
                }
            } catch (e: Exception) {
                log("Import error: ${e.message}")
            }
        }
    }

    private fun openMinecraft() {
        val i = packageManager.getLaunchIntentForPackage(mc)
        if (i != null) startActivity(i) else toast("Minecraft install nahi mila")
    }
}
